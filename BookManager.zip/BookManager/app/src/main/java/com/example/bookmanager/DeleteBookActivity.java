package com.example.bookmanager;

import android.text.TextUtils;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent; // Add this import statement

public class DeleteBookActivity extends AppCompatActivity {
    private EditText editTextDeleteISBN;
    private Button buttonDeleteBook;
    private MaBaseSQLite dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_book);

        editTextDeleteISBN = findViewById(R.id.editTextDeleteISBN);
        buttonDeleteBook = findViewById(R.id.buttonDeleteBook);

        dbHelper = new MaBaseSQLite(this, "MyBooksDB", null, 1);

        buttonDeleteBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String isbnToDelete = editTextDeleteISBN.getText().toString();

                if (TextUtils.isEmpty(isbnToDelete)) {
                    // Show an error message if ISBN to delete is empty
                    Toast.makeText(DeleteBookActivity.this, "ISBN to delete is required", Toast.LENGTH_SHORT).show();
                } else {
                    boolean bookDeleted = dbHelper.deleteBookByISBN(isbnToDelete);

                    if (bookDeleted) {
                        // Book was deleted successfully
                        Toast.makeText(DeleteBookActivity.this, "Book deleted successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(DeleteBookActivity.this, DisplayBookActivity.class);
                        startActivity(intent);
                    } else {
                        // Book doesn't exist in the database
                        Toast.makeText(DeleteBookActivity.this, "Book with ISBN " + isbnToDelete + " doesn't exist", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
