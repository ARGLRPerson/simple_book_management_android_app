package com.example.bookmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.content.Intent;
import com.example.bookmanager.MaBaseSQLite;
import com.example.bookmanager.Livre;
import java.util.List;

public class DisplayBookActivity extends AppCompatActivity {
    private TextView textViewBookDetails;
    private MaBaseSQLite dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_books);

        // Initialize your TextView
        textViewBookDetails = findViewById(R.id.textViewBookDetails);

        // Initialize your database helper
        dbHelper = new MaBaseSQLite(this, "MyBooksDB", null, 1);

        // Retrieve the list of books from the database
        List<Livre> books = dbHelper.getAllBooks();

        // Format the list of books
        StringBuilder bookList = new StringBuilder();
        for (Livre book : books) {
            bookList.append("Title: ").append(book.getTitle()).append("\n");
            bookList.append("ISBN: ").append(book.getIsbn()).append("\n");
            bookList.append("\n");
        }

        // Set the formatted list as the text of the TextView
        textViewBookDetails.setText(bookList.toString());

        // Call a method to create buttons for each book
        createButtonsForBooks(books);
    }

    // Create buttons for each book and add them to a LinearLayout
    private void createButtonsForBooks(List<Livre> books) {
        LinearLayout linearLayout = findViewById(R.id.buttonContainer);

        for (final Livre book : books) {
            Button button = new Button(this);
            button.setText(book.getTitle());

            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(DisplayBookActivity.this, DisplayBookDetailsActivity.class);
                    intent.putExtra("bookTitle", book.getTitle());
                    intent.putExtra("bookISBN", book.getIsbn());
                    startActivity(intent);
                }
            });

            linearLayout.addView(button);
        }
    }

}
