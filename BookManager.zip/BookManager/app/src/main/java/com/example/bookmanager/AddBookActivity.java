package com.example.bookmanager;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase; // Import SQLiteDatabase
import com.example.bookmanager.MaBaseSQLite;
import android.text.TextUtils;

public class AddBookActivity extends AppCompatActivity {
    private EditText editTextISBN;
    private EditText editTextTitle;
    private Button buttonAddBook;
    private MaBaseSQLite dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        editTextISBN = findViewById(R.id.editTextISBN);
        editTextTitle = findViewById(R.id.editTextTitle);
        buttonAddBook = findViewById(R.id.buttonAddBook);

        dbHelper = new MaBaseSQLite(this, "MyBooksDB", null, 1);
        db = dbHelper.getWritableDatabase();

        buttonAddBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String isbn = editTextISBN.getText().toString();
                String title = editTextTitle.getText().toString();

                if (TextUtils.isEmpty(isbn) || TextUtils.isEmpty(title)) {
                    // Show an error message if ISBN or title is empty
                    Toast.makeText(AddBookActivity.this, "Both ISBN and Title are required", Toast.LENGTH_SHORT).show();
                } else {
                    Livre livre = new Livre();
                    livre.setIsbn(isbn);
                    livre.setTitle(title);

                    if (dbHelper.addBook(livre)) {
                        // Book added successfully, show the success message
                        Toast.makeText(AddBookActivity.this, "Book added successfully", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(AddBookActivity.this, DisplayBookActivity.class);
                        startActivity(intent);
                    } else {
                        // Book addition failed, show an error message
                        Toast.makeText(AddBookActivity.this, "Failed to add the book", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
