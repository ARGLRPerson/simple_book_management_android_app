package com.example.bookmanager;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity; // You might need to import this based on your project's configuration.

public class DisplayBookDetailsActivity extends AppCompatActivity { // Make sure to extend AppCompatActivity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_book_details);

        TextView textViewBookTitle = findViewById(R.id.textViewBookTitle);
        TextView textViewBookISBN = findViewById(R.id.textViewBookISBN);

        // Add the code snippet here
        String bookTitle = getIntent().getStringExtra("bookTitle");
        String bookISBN = getIntent().getStringExtra("bookISBN");

        if (bookTitle != null && bookISBN != null) {
            textViewBookTitle.setText(bookTitle);
            textViewBookISBN.setText("ISBN: " + bookISBN);
        }

        // Add code to populate other TextViews with additional book details if needed.
    }

}
