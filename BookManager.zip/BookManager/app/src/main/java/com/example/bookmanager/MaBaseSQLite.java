package com.example.bookmanager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import java.util.ArrayList;
import java.util.List;
import android.database.Cursor;
import android.text.TextUtils;

public class MaBaseSQLite extends SQLiteOpenHelper {

    // Constructor
    public MaBaseSQLite(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version); // Increment the version number

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the "books" table
        String createTable = "CREATE TABLE IF NOT EXISTS books " +
                "(id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "isbn TEXT NOT NULL, " +
                "title TEXT NOT NULL);";

        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the existing "books" table
        db.execSQL("DROP TABLE IF EXISTS books;");

        // Recreate the "books" table with the updated schema
        onCreate(db);
    }

    public boolean addBook(Livre livre) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Get ISBN and title from the Livre object
        String isbn = livre.getIsbn();
        String title = livre.getTitle();

        if (TextUtils.isEmpty(isbn) || TextUtils.isEmpty(title)) {
            // Show an error message if ISBN or title is empty
            return false;
        }

        // Add book information to ContentValues
        values.put("isbn", isbn);
        values.put("title", title);

        long result = db.insert("books", null, values); // Insert the book into the "books" table

        // Close the database connection
        db.close();

        return result != -1; // Check if insertion was successful and return true, otherwise, return false
    }
    public boolean deleteBookByISBN(String isbn) {
        SQLiteDatabase db = this.getWritableDatabase();

        if (TextUtils.isEmpty(isbn)) {
            // Show an error message if ISBN to delete is empty
            db.close();
            return false;
        }

        // Define the WHERE clause to specify which book to delete based on ISBN
        String whereClause = "isbn = ?";

        // Specify the ISBN value to match
        String[] whereArgs = { isbn };

        // Delete the book from the database
        int rowsAffected = db.delete("books", whereClause, whereArgs);

        // Close the database connection
        db.close();

        return rowsAffected > 0; // Check if any rows were affected (book deleted successfully) and return true, otherwise, return false
    }


    public List<Livre> getAllBooks() {
        List<Livre> booksList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        // Define the columns you want to retrieve from the "books" table
        String[] columns = { "id", "isbn", "title" }; // Make sure these column names match your table

        // Query the database to retrieve all books
        Cursor cursor = db.query("books", columns, null, null, null, null, null);

        try {
            if (cursor != null && cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndex("id");
                int isbnIndex = cursor.getColumnIndex("isbn");
                int titleIndex = cursor.getColumnIndex("title");

                do {
                    int id = cursor.getInt(idIndex);
                    String isbn = cursor.getString(isbnIndex);
                    String title = cursor.getString(titleIndex);

                    Livre livre = new Livre(id, isbn, title);
                    booksList.add(livre);
                } while (cursor.moveToNext());
            }
        } finally {
            // Close the cursor
            if (cursor != null) {
                cursor.close();
            }
        }

        // Close the database connection
        db.close();

        return booksList;
    }


    public Livre getBookByISBN(String isbn) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Define the columns you want to retrieve from the "books" table
        String[] columns = { "id", "isbn", "title" };

        // Define the WHERE clause to specify which book to retrieve based on ISBN
        String selection = "isbn = ?";

        // Specify the ISBN value to match
        String[] selectionArgs = { isbn };

        // Query the database to retrieve the book
        Cursor cursor = db.query("books", columns, selection, selectionArgs, null, null, null);

        Livre book = null;

        try {
            // If the cursor contains a book, move to the first row and create a Livre object
            if (cursor.moveToFirst()) {
                int idIndex = cursor.getColumnIndex("id");
                int titleIndex = cursor.getColumnIndex("title");

                int id = cursor.getInt(idIndex);
                String title = cursor.getString(titleIndex);

                book = new Livre(id, isbn, title);
            }
        } finally {
            // Close the cursor and database connection
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }

        return book;
    }



}
