package com.example.bookmanager;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

    private TextView textViewBookDetails;
    private Button buttonAddBook;
    private Button buttonDeleteBook; // Add this button declaration
    private Button buttonDisplayBooks; // Add this button declaration

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize your TextView
        textViewBookDetails = findViewById(R.id.textViewBookDetails);

        // Initialize your buttons
        buttonAddBook = findViewById(R.id.buttonAddBook);
        buttonDeleteBook = findViewById(R.id.buttonDeleteBook); // Initialize delete button
        buttonDisplayBooks = findViewById(R.id.buttonDisplayBooks); // Initialize display button

        // Set click listeners for the buttons
        buttonAddBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to navigate to the AddBookActivity
                Intent intent = new Intent(MainActivity.this, AddBookActivity.class);
                startActivity(intent);
            }
        });

        buttonDeleteBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to navigate to the DeleteBookActivity
                Intent intent = new Intent(MainActivity.this, DeleteBookActivity.class);
                startActivity(intent);
            }
        });

        buttonDisplayBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create an intent to navigate to the DisplayBookActivity
                Intent intent = new Intent(MainActivity.this, DisplayBookActivity.class);
                startActivity(intent);
            }
        });

        // Initialize your database helper
        MaBaseSQLite dbHelper = new MaBaseSQLite(this, "MyBooksDB", null, 1);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // You can continue with the code you have for retrieving and displaying book details here.
    }
}
